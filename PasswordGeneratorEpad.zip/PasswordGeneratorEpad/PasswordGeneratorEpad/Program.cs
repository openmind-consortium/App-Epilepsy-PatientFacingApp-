﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Security.Cryptography;

namespace PasswordGeneratorEpad
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                // change this, this is the password to be encrypted
                string original = "example";

                Console.WriteLine("Enter string to be encrypted:");
                original = Console.ReadLine();

                int myIterations = 1000;
                byte[] salt1 = new byte[8];
                using (RNGCryptoServiceProvider rngCsp = new RNGCryptoServiceProvider())
                {
                    rngCsp.GetBytes(salt1);
                }
                Rfc2898DeriveBytes k1 = new Rfc2898DeriveBytes(original, salt1, myIterations);

                byte[] my_hash = k1.GetBytes(16);


                //Display the original data and the encrypted data.
                Console.WriteLine("Original:   {0}", original);
                string encrypted_string = ByteArrayToString(my_hash);
                Console.WriteLine("Hash:   " + encrypted_string);
                string salt_string = ByteArrayToString(salt1);
                Console.WriteLine("Salt: " + salt_string);
                Console.WriteLine();
                Console.WriteLine("Password written to file password.txt");

                System.IO.StreamWriter outfile = new System.IO.StreamWriter("password.txt");
                outfile.WriteLine(encrypted_string);
                outfile.WriteLine(salt_string);
                outfile.Close();

                // Go through process again, with same salt, to make sure it is repeatable
                byte[] salt2 = StringToByteArray(salt_string);
                Rfc2898DeriveBytes k2 = new Rfc2898DeriveBytes(original, salt2, myIterations);
                byte[] my_hash2 = k2.GetBytes(16);
                string encrypted_string2 = ByteArrayToString(my_hash2);
                Console.WriteLine();
                Console.WriteLine("Verified hash:   " + encrypted_string2);
                Console.WriteLine();


                Console.ReadLine();

            }
            catch (Exception e)
            {
                Console.WriteLine("Error: {0}", e.Message);
            }
        }

        static string ByteArrayToString(byte[] ba)
        {
            return BitConverter.ToString(ba).ToLower().Replace("-", "");
        }

        public static byte[] StringToByteArray(string hex)
        {
            var NumberChars = hex.Length;
            var bytes = new byte[NumberChars / 2];

            for (var i = 0; i < NumberChars; i += 2)
                bytes[i / 2] = Convert.ToByte(hex.Substring(i, 2), 16);

            return bytes;
        }
        
    }
}




